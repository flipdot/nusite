import sys
import os
import subprocess

#allows tty1 to be written from other processes
os.system("sudo chmod 666 /dev/tty1")

#all standard output is redirected to tty1
sys.stdout = open('/dev/tty1', 'w')

#ersetzt print(), sinnvoll weil print zwingend ein space am ende sendet
#dieser aufruf jedoch nicht
# ----------------- !!! text der mit sys.stdout.write(string) geschrieben wird, laesst sich NICHT mit cls() loeschen!!!!
#instead of print() use write() which does not sent CR or LF at the end
def write(string):
    sys.stdout.write(string)

#http://www.termsys.demon.co.uk/vtansi.htm
#set text (foreground) and background color
def set_color(fg, bg = "black"):
    color_code = {"black":30, "red":31, "green":32, "yellow":33, "blue":34, "magenta":35, "cyan":36, "white":37}
    write ("\033["+str(color_code[fg])+";"+str(color_code[bg]+10)+"m") # color code for background is foreground code + 10

#clear screen
def cls():
    write ("\033[2J")

#resettext attributes to white on black
def reset():
    write ("\033[0m")

#brighter text
def bright():
    write ("\033[1m")

#no blink, but grey background
def blink():
    write ("\033[5m")

#swap foreground and backgound color
def reverse():
    write ("\033[7m")

def hidecursor():
    write ("\033[?25l")

def showcursor():
    write ("\033[?25h")

def backlight_off():
    os.system('sudo sh -c "echo 1 > /sys/class/backlight/fb_ili9341/bl_power"')

def backlight_on():
    os.system('sudo sh -c "echo 0 > /sys/class/backlight/fb_ili9341/bl_power"')

#set cursor to (row, column)
#(1,1) upper left corner
#font "ProFont6x11": max (21,53)
#font "7x14": max (17,45)
def cursor(row,col):
    write ("\033["+str(row)+";"+str(col)+"H")

