import datetime														# time and 
import serial
from time import *
import sys
import os
import subprocess
import lcd

#allows tty1 to be written from other processes
os.system("sudo chmod 666 /dev/tty1")

#all standard output is redirected to tty1
sys.stdout = open('/dev/tty1', 'w')

baudrate = 9600														# communication baudrate 
# initialise serial connection 
ser = serial.Serial("/dev/ttyAMA0",baudrate,xonxoff=False)

max_wait_for_rx_timeout = 2000										# wait max. n milliseconds for return string of can client
eol_char_rx = chr(10)												# this is the character(s) at the end of a complete input line, sent by AVR
																	# only ONE character!
max_buffer_length = 10												# max number of characters received for processing buffer ..
																	# without receiving eol_char_rx
													
lcd.cls()
sys.stdout.flush()		
lcd.reset()
lcd.cursor(1,1)

ref_row_1 = 0.0
ref_row_2 = 0.0
ref_row_20 = 0.0
ref_row_21 = 0.0
ref_row_dist = 0.0
current_row = 0.0
current_row_int = 0

ref_col_1 = 0.0
ref_col_2 = 0.0
ref_col_72 = 0.0
ref_col_73 = 0.0
ref_col_dist = 0.0
current_col = 0.0
current_col_int = 0

				
# insert calibration routine here
ref_row_2 = 219.0
ref_row_20 = 835.0
ref_col_2 = 123.0
ref_col_72 = 941.0

ref_row_dist = (ref_row_20 - ref_row_2) / 18
ref_row_1 = ref_row_2 - ref_row_dist					

ref_col_dist = (ref_col_72 - ref_col_2) / 70
ref_col_1 = ref_col_2 - ref_col_dist


count = 0
while (count < 1533):
	lcd.write ("O")
	count = count + 1
sys.stdout.flush()

sleep(3)

					
input_line = ""																	
returnstring = ""

while True:
	maxwait = max_wait_for_rx_timeout
	while (maxwait > 0):
		if ser.inWaiting() > 0:										# received character waiting in uart buffer
			saveline = False										# reset flag
			s = ser.read()											# read one byte from serial input line
			if s == eol_char_rx:									# end of line character received?
				saveline = True										# received line so far will be processed later
			elif ord(s) > 31 :										# if received character is no control code, then ..
				input_line = input_line + s							# append received character to buffer
				if len(input_line) >= max_buffer_length:			# maximum buffer length reached?
					saveline = True
			if saveline == True:
				if input_line == "RELEASE":
					input_line = ""									# then discard received line, because its an echo of raspis own CAN bus command.				
				else:												# this line must be from CAN client out there
					returnstring = input_line						# save received line in output buffer: new_input_line
					input_line = ""									# clear temp input buffer
					returnstring = returnstring.strip()	 			# remove spaces at end and beginning
					maxwait = 0
					timeouterror = False
		else:														# no char waiting, sleep for 1 ms
			sleep(0.001)
			maxwait = maxwait - 1
	#print returnstring
	pos = returnstring.find(",") 									# look for separator "," between row and loumn value (not present if string ..
	if pos != -1:												# empty 
		col, row = returnstring.split(",")						# part before "," is row, part after "," is column
	
	
	lcd.cursor(10,1)
	current_row = (float(row) - ref_row_1) / ref_row_dist
	current_row_int = int(round(current_row)) + 1
	
	current_col = (float(col) - ref_col_1) / ref_col_dist
	current_col_int = int(round(current_col)) + 1
	
	print "zeile " + row + "   " + str(current_row) + " " + str(current_row_int) + "   "
	print "spalte " + col + "   " + str(current_col) + " " + str(current_col_int) + "   "
	print 
	
	
	lcd.set_color("magenta","black")
	lcd.cursor(current_row_int,current_col_int)
	lcd.write ("X")
	lcd.reset()
	sys.stdout.flush()
	
ser.close()

