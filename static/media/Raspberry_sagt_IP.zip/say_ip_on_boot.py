import subprocess
import os
import time

# Very Linux Specific, obtain IP address of PI
arg='ip route list'
p=subprocess.Popen(arg,shell=True,stdout=subprocess.PIPE)
data = p.communicate()
split_data = data[0].split()
ipaddr = split_data[split_data.index('src')+1]

os.system('mpg321 IP.mp3')
octets = ipaddr.split(".")

def say_address(octets):
	o = 0
	for octet in octets:
		for i in range (0, len(octet)):
			os.system("mpg321 %s.mp3" % octet[i])
			time.sleep(0.2)
		if o < 3:
			os.system("mpg321 point.mp3")
		o += 1
		time.sleep(0.4)
	return

say_address(octets)
os.system("mpg321 repeat.mp3")
say_address(octets)

