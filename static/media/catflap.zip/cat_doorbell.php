<?php
$output = shell_exec('mpc');
//echo $output;

//find the first part after "#", which is track number: .. lots of text ... [playing] #17/17 
list($a, $b) = explode("#", $output);
//find part left of "/", which is the track number alone
list($a) = explode("/", $b);
echo $a;
// cat doorbell audio is at location 18
$output = shell_exec('mpc play 18');
sleep (3);
// test if no track or stream was playing before alert, then $a == ""
if (!($a == ""))
	{
	$output = shell_exec('mpc play '.$a);
	}

?>


