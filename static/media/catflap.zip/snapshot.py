import RPi.GPIO as GPIO
import time
import os
import ftplib
import urllib2

GPIO.setmode(GPIO.BCM)
GPIO.setup(4, GPIO.IN, pull_up_down=GPIO.PUD_UP)

while True:
	while (GPIO.input(4)==True):
		date_string = time.strftime("%Y-%m-%d_%H-%M-%S_")
		capturecommand = "raspistill -awb fluorescent -t 0 -o /var/www/"+date_string+".jpg -w 1296 -h 972"
		os.system(capturecommand)
		date_string2 = time.strftime("%Y-%m-%d_%H-%M-%S_")
		capturecommand = "raspistill -awb fluorescent -t 0 -o /var/www/"+date_string2+".jpg -w 1296 -h 972"
		os.system(capturecommand)
		date_string = time.strftime("%Y-%m-%d_%H-%M-%S_")
		capturecommand = "raspistill -awb fluorescent -t 0 -o /var/www/"+date_string+".jpg -w 1296 -h 972"
		os.system(capturecommand)
		date_string = time.strftime("%Y-%m-%d_%H-%M-%S_")
		capturecommand = "raspistill -awb fluorescent -t 0 -o /var/www/"+date_string+".jpg -w 1296 -h 972"
		os.system(capturecommand)
		copycommand = "cp /var/www/"+date_string2+".jpg /var/www/catcam.jpg"
		os.system(copycommand)

		response = urllib2.urlopen('http://192.168.178.33/katzenklappe/cat_doorbell.php')
		html = response.read()
		
		FTP_SERVER = 'myserver.de'
		FTP_USER = 'myaccountname'
		FTP_PASSW = 'mypassword'
		FTP_PREFIX = '/'
		s = ftplib.FTP(FTP_SERVER,FTP_USER,FTP_PASSW) 
		f = open("/var/www/catcam.jpg")
		filed = 'catcam.jpg'
		s.storbinary('STOR ' + filed, f) 
		f.close() 
		s.quit()
	time.sleep(0.1)
	


	